export const getRequiredTributes = (starRating: number) => {
  if (starRating < 5) return 0;
  if (starRating >= 5 && starRating <= 6) return 1;
  if (starRating >= 7 && starRating <= 8) return 2;
  if (starRating >= 9 && starRating <= 12) return 3;
  else return 5;
};
