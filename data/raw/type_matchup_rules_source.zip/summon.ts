export enum Summon {
  Pyro,
  Forest,
  Wind,
  Earth,
  Thunder,
  Aqua,
  Shadow,
  Light,
  Fiend,
  Dreams,
  Divine,
}
