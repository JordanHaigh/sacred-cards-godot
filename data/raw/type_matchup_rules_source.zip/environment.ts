export enum Environment {
  Mountains,
  Dark,
  Wasteland,
  Field,
  Forest,
  Sea,
}
