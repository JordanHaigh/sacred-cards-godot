export enum MonsterType {
  Dragon,
  Magician,
  Zombie,
  Warrior,
  BeastWarrior,
  Beast,
  WingedBeast,
  Fiend,
  Fairy,
  Insect,
  Dinosaur,
  Reptile,
  Fish,
  SeaSerpent,
  Machine,
  Thunder,
  Aqua,
  Pyro,
  Rock,
  Plant,
}

export enum EffectType {
  Magic,
  Trap,
  Spell,
  Ritual,
}
