import { Environment } from './environment';
import { MonsterType } from './monsterType';

const advantageRules: { [key in MonsterType]?: Environment[] } = {
  [MonsterType.Dragon]: [Environment.Mountains],
  [MonsterType.Magician]: [Environment.Dark],
  [MonsterType.Zombie]: [Environment.Wasteland],
  [MonsterType.Warrior]: [Environment.Field],
  [MonsterType.BeastWarrior]: [Environment.Forest, Environment.Field],
  [MonsterType.WingedBeast]: [Environment.Mountains],
  [MonsterType.Fiend]: [Environment.Dark],
  [MonsterType.Insect]: [Environment.Forest],
  [MonsterType.Dinosaur]: [Environment.Wasteland],
  [MonsterType.Fish]: [Environment.Sea],
  [MonsterType.SeaSerpent]: [Environment.Sea],
  [MonsterType.Thunder]: [Environment.Mountains, Environment.Sea],
  [MonsterType.Aqua]: [Environment.Sea],
  [MonsterType.Rock]: [Environment.Wasteland],
  [MonsterType.Plant]: [Environment.Forest],
};

const disadvantageRules: { [key in MonsterType]?: Environment[] } = {
  [MonsterType.Fairy]: [Environment.Dark],
  [MonsterType.Machine]: [Environment.Sea],
  [MonsterType.Pyro]: [Environment.Sea],
};

export const TypeEnvironmentRules = {
  hasAdvantage(type: MonsterType, environment: Environment): boolean {
    return advantageRules[type]?.includes(environment) ?? false;
  },

  hasDisadvantage(type: MonsterType, environment: Environment): boolean {
    return disadvantageRules[type]?.includes(environment) ?? false;
  },
};
