import { Summon } from './summon';

export function superiorTo(summon1: Summon, summon2: Summon): boolean {
  const superiorityRules: { [key in Summon]?: Summon[] } = {
    [Summon.Pyro]: [Summon.Forest],
    [Summon.Forest]: [Summon.Wind],
    [Summon.Wind]: [Summon.Earth],
    [Summon.Earth]: [Summon.Thunder],
    [Summon.Thunder]: [Summon.Aqua],
    [Summon.Aqua]: [Summon.Pyro],

    [Summon.Shadow]: [Summon.Light],
    [Summon.Light]: [Summon.Fiend],
    [Summon.Fiend]: [Summon.Dreams],
    [Summon.Dreams]: [Summon.Shadow],
  };

  return superiorityRules[summon1]?.includes(summon2) ?? false;
}
