import { Summon } from './summon';
import { EffectType, MonsterType } from './monsterType';

// eslint-disable-next-line @typescript-eslint/no-unused-vars
interface Card {
  id: number;
  name: string;
  cost: number;
  description: string;
  effect: string;
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
interface NormalMonsterCard extends Card {
  type: MonsterType;
  summon: Summon;
  attack: number;
  defence: number;
  starRating: number;
  //Star rating determines sacrifice amount...
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
interface EffectMonsterCard extends Card {
  effectConditions: string; //TODO:: we'll build up an enum of all possible effect conditions
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
interface RitualMonsterCard extends Card {
  ritualConditions: string; //TODO:: we'll build up an enum of all possible ritual conditions
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
interface MagicCard extends Card {
  type: EffectType;
}
